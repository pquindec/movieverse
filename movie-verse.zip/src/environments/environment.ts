export const environment = {
  production: false,
  apiUrl: 'https://api.themoviedb.org/3',
  apiKey: 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJjNmQxN2E1MjdkNmMzMThlM2VhZmNiOWMxYTE4MTNhYyIsInN1YiI6IjVjZmE4MzAyOTI1MTQxNjczN2MxZWM1MSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.7fjGIjIuVoHVrG1by8RjJ2g2rAzIxXOCEzkKV9AHPqg'
};
